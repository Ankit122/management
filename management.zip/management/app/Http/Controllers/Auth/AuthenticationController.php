<?php

namespace App\Http\Controllers\Auth;



use App\User;
use Validator;
use App\Http\Controllers\Controller;
use Illuminate\Foundation\Auth\ThrottlesLogins;
use Illuminate\Foundation\Auth\AuthenticatesAndRegistersUsers;
use Illuminate\Http\Request;
use Redirect;
use Auth;
use Session;
use View;
use Hash;
use DB;
use Mail;
//use Request;

use App\Role;
use App\Permission;


class AuthenticationController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Registration & Login Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles the registration of new users, as well as the
    | authentication of existing users. By default, this controller uses
    | a simple trait to add these behaviors. Why don't you explore it?
    |
    */

    use AuthenticatesAndRegistersUsers, ThrottlesLogins;

    public function userLogout(){

        Auth::logout();
        return Redirect::to('/');

    }
   
    public function postLogin(Request $req){

        $inputemail          = $req->email;
        $password            = $req->password;
        $rememberme          = $req->rememberme;

        $inputs = [
            'inputemail'     => $inputemail,
            'password'       => $password,


        ];

        $rules = [
            'inputemail'      => 'required|email',
            'password'        => 'required'
        ];

        $messages = [
            'inputemail.required' => 'Email is required.',
            'inputemail.email'    => 'not a valid email.',
            'password.required'   => 'Password is required.',
            

        ];

       $validation = Validator::make($inputs, $rules, $messages);

        if( $validation->fails() ){
            return redirect()->back()->withInput()->with('errors', $validation->errors() );
        }

       
        

        $userdata = array(
            'email'    => $inputemail,
            'password' => $password 
        );
        
        $remember = false;
        if($rememberme != ''){
            $remember = true;
        }
        

        if(Auth::attempt($userdata, $remember)){
                
            return Redirect::to('emp_list');

        } else { 

            Session::flash('flash_message', 'Either email or password is wrong.');
            return redirect()->back();
        }


        //return $request->email;
    }

   
    
}
