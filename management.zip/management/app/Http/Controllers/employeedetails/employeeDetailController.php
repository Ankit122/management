<?php
namespace App\Http\Controllers\employeedetails;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Validator;
use Redirect;
use DB;
use App\Http\Requests;
use Image;
use File;
use Mail;
use Mailgun;
use DateTime;




class employeeDetailController extends Controller
{
    public function insertemployeeDetails(Request $req){
       
        $emp_firstname             = $req->emp_firstname;
        $emp_middlename            = $req->emp_middlename;
        $emp_lastname              = $req->emp_lastname;
        $emp_id                    = $req->emp_id;
        $emp_designation           = $req->emp_designation;
        $emp_department            = $req->emp_department;
        $joining_date              = $req->joining_date;
        $termination_date          = $req->termination_date;
        $status                    = $req->status;

        

       $inputs = [
            'emp_firstname'        => $emp_firstname,
            'emp_middlename'       => $emp_middlename,
            'emp_lastname'         => $emp_lastname,
            'emp_id'               => $emp_id,
            'emp_designation'      => $emp_designation,
            'emp_department'       => $emp_department,
            'joining_date'         => $joining_date,
            'termination_date'     => $termination_date,
            'status'               => $status,
            
        ];

        $rules = [
            'emp_firstname'        => 'required|max:25',
            'emp_lastname'         => 'required',
            'emp_id'               => 'required|min:6|max:10|unique:employee_detail|regex:/^[A-Z]{6}\d{4}$/',
            'emp_designation'      => 'required',
            'emp_department'       => 'required',
            'joining_date'         => 'required',
            'status'               => 'required',
        ];

        $messages = [
            'emp_firstname.required'    => 'Firstname is required.',
            'emp_middlename.required'   => 'Middle name is required.',
            'emp_lastname.required'     => 'Last name is required.',
            'emp_id.required'           => 'Employee ID required.',
            'emp_designation.required'  => 'Designation is required.',
            'emp_department.required'   => 'Depertment is required.',
            'joining_date.required'     => 'Joining Date is required.',
            'termination_date.required' => 'termination date is required.',
            'status.required'           => 'status is required.',

        ];

       $validation = Validator::make($inputs, $rules, $messages);
        

        if( $validation->fails() ){
            return redirect()->back()->withInput()->with('errors', $validation->errors() );
        }


        /*STEP1 INSERT*/

        DB::table('employee_detail')->insert([
            'emp_firstname'        => $emp_firstname,
            'emp_middlename'       => $emp_middlename,
            'emp_lastname'         => $emp_lastname,
            'emp_id'               => $emp_id,
            'emp_designation'      => $emp_designation,
            'emp_department'       => $emp_department,
            'joining_date'         => $joining_date,
            'termination_date'     => $termination_date,
            'status'               => $status
           
        ]);

       
          return redirect()->back()->withInput()->with('message', 'Saved successfully');


    }


    public function addemployeeDetails(Request $req){

        $emp_firstname             = $req->emp_firstname;
        $emp_middlename            = $req->emp_middlename;
        $emp_lastname              = $req->emp_lastname;
        $emp_id                    = $req->emp_id;
        $email                     = $req->email;
        $emp_designation           = $req->emp_designation;
        $emp_department            = $req->emp_department;
        $joining_date              = $req->joining_date;
        $status                   = $req->status;
        $emp_photo                 = $req->file('emp_photo');

        $inputs = [
            'emp_firstname'        => $emp_firstname,
            'emp_middlename'       => $emp_middlename,
            'emp_lastname'         => $emp_lastname,
            'emp_id'               => $emp_id,
            'email'               => $email,
            'emp_designation'      => $emp_designation,
            'emp_department'       => $emp_department,
            'joining_date'         => $joining_date,
            'status'               => $status,
            'emp_photo'            => $emp_photo,
        ];

        $rules = [
            'emp_firstname'        => 'required|max:50|regex:/^[a-zA-Z ]*$/',
            'emp_lastname'         => 'required|max:50|regex:/^[a-zA-Z ]*$/',
            'emp_id'               => 'required|alpha_num|min:5|max:10|regex:/^[A-Z]{5}\d{4}$/',
            'emp_designation'      => 'required',
            'email'                => 'required',
            'emp_department'       => 'required',
            'joining_date'         => 'required',
            'status'               => 'required',
           
            
        ];

        $messages = [
                'emp_id.required'           => 'Employee ID required.',
                'emp_firstname.required'    => 'Firstname is required.',
                'emp_middlename.required'   => 'Middile name is required.',
                'emp_lastname.required'     => 'Last name is required.',
                'email.required'            => 'Email is required.',
                'emp_designation.required'  => 'Designation is required.',
                'emp_department.required'   => 'Depertment is required.',
                'joining_date.required'     => 'Joining Date is required.',
                'emp_photo.required'        => 'Image is required.',
                
            
        ];


       $validation = Validator::make($inputs, $rules, $messages);

        if( $validation->fails() ){
            return redirect()->back()->withInput()->with('errors', $validation->errors() );
        }

         if($emp_photo){
            

            $destinationPath    ='emp'; // upload path folder should be in public folder
            $thumb200x300       ='emp/thumb200x300'; // upload 128*128
            

            $extension      = $emp_photo->getClientOriginalExtension(); // getting image extension
            $originalName   = $emp_photo->getClientOriginalName();
            $size           = $emp_photo->getSize();
            $fileName1      = time().$originalName; // renameing image

            // condition to check type of file and size of file..
             if((($extension=='jpg') || ($extension=='png') || ($extension=='jpeg') || ($extension=='JPEG') || ($extension=='JPG') || ($extension=='PNG'))&&($size<250000)){


                Image::make($emp_photo,array(
                    'width' => 200,
                    'height' => 300,
                    'crop' => true
                ))->save($thumb200x300.'/'.$fileName1);
                //save original
                 Image::make($emp_photo)->save($destinationPath.'/'.$fileName1);
 
            } else {
                return redirect()->back()->withInput()->with('error', 'Only maximum 205 KB jpg or png image is allowed.' );
            }
        } else {
            $fileName1 = '';
        }


        DB::table('employee_detail')->insert([
            'emp_firstname'        => $emp_firstname,
            'emp_middlename'       => $emp_middlename,
            'emp_lastname'         => $emp_lastname,
            'emp_id'               => $emp_id,
            'email'                => $email,
            'emp_designation'      => $emp_designation,
            'emp_department'       => $emp_department,
            'joining_date'         => $joining_date,
            'status'               => $status,
            'emp_photo'            => $fileName1
            
        ]);
       
          return redirect()->back()->withInput()->with('message', 'Employee Added successfully');
    
   }
  
  
    public function editEmpRecords(Request $req){

        $emp_firstname             = $req->emp_firstname;
        $emp_middlename            = $req->emp_middlename;
        $emp_lastname              = $req->emp_lastname;
        $emp_id                    = $req->emp_id;
        $emp_designation           = $req->emp_designation;
        $emp_department            = $req->emp_department;
        $joining_date              = $req->joining_date;
        $termination_date          = $req->termination_date;
        $status                    = $req->status;
        $emp_photo                 = $req->file('emp_photo');
        $id                        = $req->id;   



        $inputs = [
            'emp_firstname'        => $emp_firstname,
            'emp_middlename'       => $emp_middlename,
            'emp_lastname'         => $emp_lastname,
            'emp_id'               => $emp_id,
            'emp_designation'      => $emp_designation,
            'emp_department'       => $emp_department,
            'joining_date'         => $joining_date,
            'termination_date'     => $termination_date,
            'status'               => $status,
            'emp_photo'            => $emp_photo,
            
        ];

        $rules = [
            'emp_firstname'        => 'required|max:50|regex:/^[a-zA-Z ]*$/',
            'emp_lastname'         => 'required|max:50|regex:/^[a-zA-Z ]*$/',
            'emp_id'               => 'required|alpha_num|min:5|max:10|regex:/^[A-Z]{5}\d{4}$/',
            'emp_designation'      => 'required',
            'emp_department'       => 'required',
            'joining_date'         => 'required',
            'status'               => 'required',
        ];

        $messages = [

                'emp_id.required'           => 'Employee ID required.',
                'emp_firstname.required'    => 'Firstname is required.',
                'emp_middlename.required'   => 'Middile name is required.',
                'emp_lastname.required'     => 'Last name is required.',
                'emp_designation.required'  => 'Designation is required.',
                'emp_department.required'   => 'Depertment is required.',
                'joining_date.required'     => 'Joining Date is required.',
                'emp_photo.required'        => 'Image is required.',
                
        ];

        $validation = Validator::make($inputs, $rules, $messages);

        if( $validation->fails() ){
            return redirect()->back()->withInput()->with('errors', $validation->errors() );
        }

        if($emp_photo){
            

            $destinationPath   ='emp'; // upload path folder should be in public folder
            $thumb200x300      ='emp/thumb200x300'; // upload 128*128
            

            $extension      = $emp_photo->getClientOriginalExtension(); // getting image extension
            $originalName   = $emp_photo->getClientOriginalName();
            $size           = $emp_photo->getSize();
            $fileName1      = time().$originalName; // renameing image

            // condition to check type of file and size of file..
             if((($extension=='jpg') || ($extension=='png') || ($extension=='jpeg') || ($extension=='JPEG') || ($extension=='JPG') || ($extension=='PNG'))&&($size<250000)){


                Image::make($emp_photo,array(
                    'width' => 200,
                    'height' => 300,
                    'crop' => true
                ))->save($thumb200x300.'/'.$fileName1);
                //save original
                 Image::make($emp_photo)->save($destinationPath.'/'.$fileName1);
 
            } else {
                return redirect()->back()->withInput()->with('error', 'Only maximum 205 KB jpg or png image is allowed.' );
            }
        } else {
            $fileName1 = '';

        }

        if ($termination_date OR $termination_date == '0000-00-00') {

             DB::table('employee_detail')->where('id', $id)->update([
            'emp_firstname'        => $emp_firstname,
            'emp_middlename'       => $emp_middlename,
            'emp_lastname'         => $emp_lastname,
            'emp_id'               => $emp_id,
            'emp_designation'      => $emp_designation,
            'emp_department'       => $emp_department,
            'joining_date'         => $joining_date,
            'termination_date'     => $termination_date,
            'emp_photo'            => $fileName1,
            'status'               => $status,
            'is_terminate'         => 'yes'
        ]);

          
        } else {



     DB::table('employee_detail')->where('id', $id)->update([
            'emp_firstname'        => $emp_firstname,
            'emp_middlename'       => $emp_middlename,
            'emp_lastname'         => $emp_lastname,
            'emp_id'               => $emp_id,
            'emp_designation'      => $emp_designation,
            'emp_department'       => $emp_department,
            'joining_date'         => $joining_date,
            'emp_photo'            => $fileName1,
            'status'               => $status
             
        ]);

    }

        return redirect()->back()->with('message', 'Record update successfully!!');
    }

    public function authenticate()
    {
        if (Auth::attempt(['email' => $email, 'password' => $password, $remember]))
        {
            return redirect()->intended('emp_list');
        }
    }

    public function signin(Request $req){

       
        $emp_screenname        = $req->emp_screenname;
        $emp_id                = $req->emp_id;
        $comments              = $req->comments;
        $system_date           = $req->system_date;
        $system_time_signin    = $req->system_time_signin;
        $server_date           = $req->server_date;
        $server_time_signin    = $req->server_time_signin;
        $machine_mac_name      = $req->machine_mac_name;
        $public_ip             = $req->public_ip;
        $local_ip              = $req->local_ip;


        $inputs = [
            'emp_screenname'   => $emp_screenname,
            'emp_id'           => $emp_id,
        ];

        $rules = [
            
            'emp_id'           => 'required|min:5|max:10|regex:/^[A-Z]{5}\d{4}$/',
            'emp_screenname'   => 'required|max:25|regex:/^[a-zA-Z ]*$/',
        ];

        $messages = [
            
            'emp_id.required'        => 'Employee ID required.',
            'emp_screenname.required'=> 'Name is required.',
        ];

        $validation = Validator::make($inputs, $rules, $messages);

        if( $validation->fails() ){
            return redirect()->back()->withInput()->with('errors', $validation->errors() );
        }

        //check for existence on emp id in employee_detail tbl.

        $count_of_empid = DB::table('employee_detail')->where('emp_id', $emp_id)->count();

        if($count_of_empid == 0){
            //No emp id exist.
            //return getenv('COMPUTERNAME');
            //return $_SERVER;
            return redirect()->back()->with('error', 'Employee ID does not exist.');
        } else {
            
            

        }

        //here first get emp id on behalf of emp id
        $fk_id = DB::table('employee_detail')->where('emp_id', $emp_id)->get();
        $fk_id = $fk_id[0]->id;


        /*STEP1 INSERT*/

        DB::table('emp_signin_signout')->insert([
            'emp_screenname'       => $emp_screenname,
            'comments'             => $comments,
            'system_date'          => $system_date,
            'system_time_signin'   => $system_time_signin,
            'server_date'          => $server_date,
            'server_time_signin'   => $server_time_signin,
            'machine_mac_name'     => $machine_mac_name,
            'public_ip'            => $public_ip,
            'local_ip'             => $local_ip,
            'fk_id'                => $fk_id
        ]);

           

        return redirect()->back()->withInput()->with('message', 'You Have Signed In.');


    }

    public function empsignOut(Request $req){

        date_default_timezone_set("Asia/Kolkata");
        $now = new DateTime();
        $server_time_signout = $now->format('H:i:s');
       
        $empsignout_id       = $req->empsignout_id;
        $system_time_signout = $req->system_time_signout;
         
        $count_of_empid = DB::table('employee_detail')->where('emp_id', $empsignout_id)->count();

        

        if($count_of_empid == 0){
            
            return redirect()->back()->with('error', 'Employee ID does not exist.');
        }
        $empid = DB::table('employee_detail')->where('emp_id', $empsignout_id)->select('id')->get();
        $empid = $empid[0]->id;

        $inputs = [
        
            'empsignout_id'       => $empsignout_id,
        ];

        $rules = [
            
            'empsignout_id'       => 'required|min:5|max:10|regex:/^[A-Z]{5}\d{4}$/',
            
        ];

        $messages = [
            
            'empsignout_id.required'   => 'Employee ID required.',
            
        ];

        $validation = Validator::make($inputs, $rules, $messages);

        if( $validation->fails() ){
            return redirect()->back()->withInput()->with('errors', $validation->errors() );
        }

        //check for existence on emp id in employee_detail tbl.


        $count_of_empid = DB::table('employee_detail')->where('emp_id', $empsignout_id)->count();

        

        if($count_of_empid == 0){
            
            return redirect()->back()->with('error', 'Employee ID does not exist.');
        } else {

            



            $issignin = DB::table('emp_signin_signout')
            ->where('server_date', date('Y-m-d'))
            ->where('fk_id', $empid)->select('server_time_signin')->get();

            //return count($issignin);

            if(count($issignin) == '0'){
                return redirect()->back()->with('error', 'Sign In first.');
            }

            $issignout = DB::table('emp_signin_signout')
            ->where('server_date', date('Y-m-d'))
            ->where('fk_id', $empid)->select('server_time_signout')->get();



            if($issignout[0]->server_time_signout != '00:00:00'){
                return redirect()->back()->with('error', 'Already signout.');
            }

            
              
        }

        
        DB::table('emp_signin_signout')->where('fk_id', $empid)->where('server_date', date('Y-m-d'))->update([

            'system_time_signout'  => $system_time_signout,
            'server_time_signout'  => $server_time_signout
            
            
        ]);

        return redirect()->back()->withInput()->with('message', 'You Have Signed Out.');


    }

     public function leave_application(Request $req){
       
        $emp_id                = $req->emp_id;
        $name                  = $req->name;
        $leave_date_to         = $req->leave_date_to    ;
        $date_from             = $req->date_from;
        $server_date           = $req->server_date;
        $description           = $req->description;
       
        $inputs = [
            'emp_id'           => $emp_id,
            'name'             => $name,
            'leave_date_to'    => $leave_date_to,
            'date_from'        => $date_from,
            'description'      => $description,
            
        ];

        $rules = [
            
            'emp_id'           => 'required|min:5|max:10|regex:/^[A-Z]{5}\d{4}$/',
            'name'             => 'required|max:25|regex:/^[a-zA-Z ]*$/',
            'leave_date_to'    => 'required|max:25',
            'date_from'        => 'required|max:25',
        ];

        $messages = [
            
            'emp_id.required'        => 'Employee ID required.',
            'name.required'          => 'Name is required.',
            'leave_date_to.required' => 'Leave date to is required.',
            'date_from.required'     => 'Date from is required.',
        ];

        $validation = Validator::make($inputs, $rules, $messages);

        if( $validation->fails() ){
            return redirect()->back()->withInput()->with('errors', $validation->errors() );
        }

        //check for existence on emp id in employee_detail tbl.

        $count_of_empid = DB::table('employee_detail')->where('emp_id', $emp_id)->count();

        if($count_of_empid == 0){
           
            return redirect()->back()->with('error', 'Employee ID does not exist.');
        } else {
            //fetch primary key from employee_detail and insert into emp_signin_signout with
            //screen name comment and date time

        }

        /*STEP1 INSERT*/

        DB::table('leave_application')->insert([
            'emp_id'        => $emp_id,
            'name'          => $name,
            'leave_date_to' => $leave_date_to,
            'date_from'     => $date_from,
            'description'   => $description,
           
        ]);


        return redirect()->back()->withInput()->with('message', 'You have applied for the Leave. Admin will get back to You.');


    }

     public function reject_application(Request $req){
       
        $reason     = addslashes($req->reason);
        $id         =$req->id;

        DB::table('leave_application')
            ->where('id', $id)
            ->update(['status' => 2]);

        return redirect()->back()->with('message', 'Application Rejected.');
    }
    public function addExpences(Request $req){
       
        $item_name             = $req->item_name;
        $pur_from              = $req->pur_from;
        $pur_date              = $req->pur_date    ;
        $quantity              = $req->quantity;
        $rate                  = $req->rate;
        $total                 = $req->total;
        $grand_total           = $req->grand_total;

        //genrate some purchase id
        $purchase_id = 'PUR'.rand(1,9999);


       
        $inputs = [
            'item_name'        => $item_name,
            'pur_from'         => $pur_from,
            'pur_date'         => $pur_date,
            'quantity'         => $quantity,
            'rate'             => $rate,
            'total'            => $total,
            'grand_total'      => $grand_total,
            'purchase_id'      => $purchase_id,
            
        ];

        $rules = [
            
            'item_name'         => 'required|min:0|max:30',
            'pur_from'          => 'required',
            'pur_date'          => 'required|max:10',
            'quantity'          => 'required|max:5',
            'rate'              => 'required|max:10',
            'purchase_id'       => 'unique:expence',

        ];

        $messages = [
            
            'item_name.required' => 'Please Fill Item Name.',
            'pur_from.required'  => 'Purchase From is required.',
            'pur_date.required'  => 'Purchase date is required.',
            'quantity.required'  => 'Product Quantity required.',
            'rate.required'      => 'Product Rate is required.',
        ];

        $validation = Validator::make($inputs, $rules, $messages);

        if( $validation->fails() ){
            return redirect()->back()->withInput()->with('errors', $validation->errors() );
        }
        /*STEP1 INSERT*/

        //return $item_name[0].$item_name[1];
       

        

        for ($i=0; $i < sizeof($item_name); $i++) { 
            DB::table('expence')->insert([
                'item_name'        => $item_name[$i],
                'pur_from'         => $pur_from[$i],
                'pur_date'         => $pur_date[$i],
                'quantity'         => $quantity[$i],
                'rate'             => $rate[$i],
                'total'            => $total[$i],
                'purchase_id'      => $purchase_id
            ]);
        }

        DB::table('expence_grand_total')->insert([
            
            'grand_total'      => $grand_total,
            'purchase_id'      => $purchase_id
        ]);

      return redirect()->back()->withInput()->with('message', 'Record Added successfully');


    }
}
