<?php

namespace App\Http\Middleware;

use Closure;
use Auth;
use DB;

class checkAdminAuth
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        
        if(Auth::check()){
            $id   = Auth::user()->id;
            $user_type = DB::table('users')->select('usertype')->where('id', '=', $id)->get();
            if($user_type[0]->usertype != 'superadmin'){
                return redirect('admin');
            }
            //$path = $request->path();
            //here path is route name
        } else {
            return redirect('admin');
        }
        return $next($request);
    }
}
