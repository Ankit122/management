<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/


//
Route::get('countries_json', function(){
	return DB::table('countries')->select('countryName')->get();
});

Route::get('state_json', function(){
	return DB::table('state_master')->select('StateName', 'id')->get();
});
Route::get('district_json/{StateName}', function($StateName){
	$state_master = DB::table('state_master')->select('id')->where('StateName', '=', $StateName)->get();
	return $district_master= DB::table('district_master')->select('DistrictName', 'id')->where('StateID', '=', $state_master[0]->id)->get();
});
Route::get('loadIndiaState', function(){
	return view('loadIndiaState');
});
Route::get('loadOtherState', function(){
	return view('loadOtherState');
});
Route::get('loadIndiaStateForPermanent', function(){
	return view('loadIndiaStateForPermanent');
});
Route::get('loadOtherStatePermanent', function(){
	return view('loadOtherStatePermanent');
});

Route::get('loadIndiaState_u', function(){

	return view('loadIndiaState_u');
});
Route::get('loadOtherState_u', function(){
	return view('loadOtherState_u');
});
Route::get('loadIndiaStateForPermanent_u', function(){
	return view('loadIndiaStateForPermanent_u');
});
Route::get('loadOtherStatePermanent_u', function(){
	return view('loadOtherStatePermanent_u');
});



Route::get('find-ifsc', function () {
    return view('find-ifsc');
});


Route::get('testgraph', function () {
    return view('testgraph');
});


Route::get('/', function () {
    return view('welcome');
});

Route::get('hr_login', function () {
    return view('hr_login');
});
Route::post('signin', 'employeedetails\employeeDetailController@signin');
Route::get('signin', function () {

    return view('signin');
});
Route::post('signOut', 'employeedetails\employeeDetailController@empsignOut');
     
Route::get('signOut', function () {
    
    return view('signOut');
});
Route::post('leaveForm', 'employeedetails\employeeDetailController@leave_application');
	Route::get('leave_application', function () {
	    return view('leave_application');
	});

// for login authentication
    Route::post('hrLogin', 'Auth\AuthenticationController@postLogin');


    Route::group(['middleware' => 'auth'],function(){

		Route::get('emp_list', function () {
			 return view('emp_list');
		});
	
		Route::get('is_terminate', function () {
			 return view('is_terminate');
		});

		Route::get('non_terminate', function () {
			 return view('non_terminate');
		});
		
		Route::get('signin_signout_report', function () {
			 return view('signin_signout_report');
		});

		Route::get('logout', 'Auth\AuthenticationController@userLogout');

		Route::get('emp_detail', function () {
		    return view('emp_detail');
		});

		Route::post('saveEmployeeDetail', 'employeedetails\employeeDetailController@insertemployeeDetails');

		Route::post('editEmployee', 'employeedetails\employeeDetailController@editEmpRecords');

		Route::get('edit_Empform/{id}', function ($id) {
			
			$emp_detail = DB::table('employee_detail')->where('id', $id)->get();
			return view('edit_Empform')->with('emp_detail', $emp_detail);
		});

		Route::post('addNewEmployee', 'employeedetails\employeeDetailController@addemployeeDetails');

		Route::get('addEmployee', function () {
			 return view('addEmployee');
		});

		Route::get('delete/{id}', function($id){
			DB::table('employee_detail')->where('id', $id)->delete();
			return redirect()->back()->with('message', 'One record deleted.');
		});
		// Leave Application Form Route Start
		
		Route::get('leaveApplicationList', function () {
		    return view('leaveApplicationList');
		});
		Route::get('application_detail/{id}', function ($id) {
			$data = array('pagetitle'=>'Application Detail');
			$applicationForm = DB::table('leave_application')->select('*')->where('id', $id)->get();
			return view('application_detail', $data)->with('applicationForm', $applicationForm);;
		});

		Route::get('approve_application/{id}', function($id){
				
				$applicationForm = DB::table('leave_application')->select('*')->where('id', $id)
						->update([
							'status'=>'1' 
		]);
			return redirect()->back()->with('message', 'Application Approve');
		});
		Route::post('reject_application', 'employeedetails\employeeDetailController@reject_application');

		Route::post('addExpences', 'employeedetails\employeeDetailController@addExpences');
              Route::get('expence', function () {
             return view('expence');
        });

        Route::get('exp_grand_total/{purchase_id}', function ($purchase_id) {
 	         $purchaseId = $purchase_id;
 	         $grand_total = DB::table('expence_grand_total')->where('purchase_id', $purchase_id)->get();
 	         
			 return view('exp_grand_total')->with('grand_total', $grand_total)->with('purch_id', $purchaseId);
		});

        Route::get('expence_list', function () {
			 return view('expence_list');
		});

	// Leave Application Route Ends Here

});

Route::get('test', function () {
		 return view('test');
	});

Route::get('test3', function () {
		 return view('test2');
	});

Route::get('dbcreat', function () {
		 DB::raw("ALTER TABLE `employee_detail` ADD `is_terminate` VARCHAR(50) NOT NULL DEFAULT 'no' AFTER `status`;");
		 
	});
Route::get('dbcreate1', function () {
		 DB::raw("ALTER TABLE `emp_signin_signout` ADD `public_ip` VARCHAR(50) NOT NULL DEFAULT 'no' AFTER `	machine_mac_name`;");
		 
	});
Route::get('dbcreate2', function () {
		 DB::raw("ALTER TABLE `emp_signin_signout` ADD `local_ip` VARCHAR(50) NOT NULL DEFAULT 'no' AFTER `	public_ip`;");
		 
	});

Route::get('dbcreate3', function () {
		 DB::raw("CREATE TABLE `expence` (
  `id` int(20) NOT NULL,
  `purchase_id` varchar(50) NOT NULL,
  `item_name` varchar(200) NOT NULL COMMENT 'item name',
  `pur_from` varchar(200) NOT NULL COMMENT 'purchase from',
  `pur_date` date NOT NULL COMMENT ' purchase date',
  `quantity` int(100) NOT NULL COMMENT 'number of products',
  `rate` int(200) NOT NULL COMMENT 'cost of product',
  `total` int(200) NOT NULL COMMENT 'total cost of products'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;");
		 
	});
Route::get('dbcreate4', function () {
		 DB::raw("ALTER TABLE `expence`
  ADD PRIMARY KEY (`id`);");
		 
	});

Route::get('dbcreate5', function () {
		 DB::raw("CREATE TABLE `expence_grand_total` (
  `id` int(8) NOT NULL,
  `purchase_id` varchar(50) NOT NULL,
  `grand_total` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;");
		 
	});
Route::get('dbcreate6', function () {
		 DB::raw("ALTER TABLE `expence_grand_total`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `purchase_id` (`purchase_id`);");
		 
	});