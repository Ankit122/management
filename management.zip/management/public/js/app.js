$(document).ready(function(){

    

  $.ajaxSetup({
        
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    
  });


    $('#subsBtnFooter').click(function(){
        alert('v');

        var SubscriberEmail = $('#SubscriberEmail').val();
        //alert(SubscriberEmail);
        $('#SubscriberEmailResp').html('');
        $('#subsBtnFooter').html('<i class="fa fa-refresh fa-spin"></i>');
        var siteurl = $('#siteurl_footer').val();

        

        if(validateEmail(SubscriberEmail)){
            //alert(SubscriberEmail);
            $.ajax({

                type: "post",
                url: siteurl+'/subscribenewsletter',
                data:{

                    'SubscriberEmail':SubscriberEmail

                },

                success: function(result){
                    alert('result');
                    $('#SubscriberEmail').val('');
                    $('#SubscriberEmailResp').html(result);
                    $('#subsBtnFooter').html('<i class="fa fa-send"></i>');

                },
                error: function (xhr,status,error) {
                    alert("Status: " + status);
                    alert("Error: " + error);
                    alert("xhr: " + xhr.readyState);
                    $('#subsBtnFooter').html('<i class="fa fa-send"></i>');
                }

            });


        } else {

            $('#SubscriberEmail').val('');
            $('#SubscriberEmailResp').html('Please enter a valid email.');
            $('#subsBtnFooter').html('<i class="fa fa-send"></i>');

        }

    });

    

  
  
});


function validateEmail(email) {
    var re = /^([\w-]+(?:\.[\w-]+)*)@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$/i;
    return re.test(email);
}


    function validation(){

        

        var nm=document.getElementById("name").value;
        if(nm == ''){
            document.getElementById("name").focus();
            $('#name').attr('placeholder', '*Required.');
            return false;
        } 

        var em=document.getElementById("email").value;
        if(em == '' || em == 'null'){
            document.getElementById("email").focus();
            $('#email').attr('placeholder', '*Required.');
            return false;
        } 

        if(!validateEmail(em)){
            document.getElementById("email").focus();
            $('#email').val('');
            $('#email').attr('placeholder', '*Please enter email.');
            return false;
        } 

        var ph=document.getElementById("phone").value;
        if(ph == ''){
            document.getElementById("phone").focus();
            $('#phone').attr('placeholder', '*Required.');
            return false;
        }

        var sub=document.getElementById("subject").value;
        if(sub == ''){
            $('#subject').attr('placeholder', '*Required.');
            document.getElementById("subject").focus();
            return false;
        } 

        var message=document.getElementById("message").value;
        if(message == ''){
            $('#message').attr('placeholder', '*Required.');
            document.getElementById("message").focus();
            return false;
        }

        var siteurl = $('#siteurl').val();
        //alert(siteurl);

        $('#contact_us_send_now').html('<i class="fa fa-refresh fa-spin"></i>');

        $.ajax({

            type: "post",
            url: siteurl+'/saveFeedback',
            data:{
                'name':nm,
                'email':em,
                'phone':ph,
                'subject':sub,
                'feedback':message
            },
            success: function(result){
                //alert(result);
                $('#contact_us_send_resp').show().html(result);
                $('#contact_us_send_now').html('SENT NOW');
                $('#name').val('');
                $('#email').val('');
                $('#phone').val('');
                $('#message').val('');
                $('#subject').val('');
                return false;
            },
            error: function (xhr,status,error) {
                alert("Status: " + status);
                alert("Error: " + error);
                alert("xhr: " + xhr.readyState);
                $('#name').val('');
                $('#email').val('');
                $('#phone').val('');
                $('#message').val('');
                $('#subject').val('');
                $('#contact_us_send_now').html('SENT NOW');
            }
        });
        $('#name').attr('placeholder', 'Your Name');
        $('#email').attr('placeholder', 'Your Email');
        $('#phone').attr('placeholder', 'Your Phone');
        $('#message').attr('placeholder', 'Message');
        $('#subject').attr('placeholder', 'Subject');
        return false;
    }

var userloginLogin = function(inputSelectorClass, thisVal){


    
    var validationresult = formvalidation(inputSelectorClass);
    //alert(validationresult);
    if(!validationresult){
        return false;
    } else {
        $('.cftlogin-area button[type="submit"]').html('<i class="fa fa-refresh fa-spin"></i>');
        //AJAX FORM VALIDATION
        var siteurl = $('#siteurl_loginform').val();
        var formdata = $( thisVal ).serialize();
        $.ajax({

            type: "post",
            url: siteurl+'/volunteerLogin',
            data:formdata,
            success: function(result){
                if(result.trim() == '1'){
                    location.reload();
                } else {
                    $('#erruserid').html(result).fadeIn();
                    $('.cftlogin-area button[type="submit"]').html('Login');
                }
                
                return false;
            },
            error: function (xhr,status,error) {
                alert("Status: " + status);
                alert("Error: " + error);
                alert("xhr: " + xhr.readyState);
                $('.cftlogin-area button[type="submit"]').html('Login');
                return false;
            }
        });
        return false;
    }
    return false;
}












