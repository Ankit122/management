appdomain = 'http://localhost/management/public/';
//appdomain = 'http://localhost/amp_front/public/';
$(function(){
	$('#currentCont').change(function(){
		$('.wrapperCurrentCityDist').hide();
		var thisval = $(this).val();
		if(thisval == 'IN'){
			$('#wrapperCurrentCityDist_india').show();
			$('#CurrentState, #CurrentDistrict').attr('validationType', '');
			$('#CurrentState_ind, #CurrentDistrict_ind').attr('validationType', 'iipl_required');
		} else {
			$('#wrapperCurrentCityDist_oth').show();
			$('#CurrentState, #CurrentDistrict').attr('validationType', 'iipl_required');
			$('#CurrentState_ind, #CurrentDistrict_ind').attr('validationType', '');
		}
	});

	$('#CurrentState_ind').change(function(){
		var StateName = $(this).val();
		//alert(StateName);
		$('#CurrentDistrict_ind').html('<option value="">Select</option>');
		$.ajax({
			type:'GET',
			url:appdomain+'district_json/'+StateName,
			success:function(result){
         result = $.parseJSON(result);
				
				for(var i=0; i<result.length; i++){
					console.log(result[i].DistrictName);
					$('#CurrentDistrict_ind').append('<option value="'+result[i].DistrictName+'">'+result[i].DistrictName+'</option>');	
				}
			},
			error: function (xhr,status,error) {
	            alert("Status: " + status);
	            alert("Error: " + error);
	            alert("xhr: " + xhr.readyState);
	        }
		});
	});

	$('#PermanentState').change(function(){
		var StateName = $(this).val();
		alert(StateName);
		$('#PermanentDistrict').html('<option value="">Select</option>');
		$.ajax({
			type:'GET',
			url:appdomain+'district_json/'+StateName,
			success:function(result){
			alert(result);
			//result = $.parseJSON(result);
				
				for(var i=0; i<result.length; i++){
					//console.log(result[i].DistrictName);
					$('#PermanentDistrict').append('<option value="'+result[i].id+'">'+result[i].DistrictName+'</option>');	
				}
			},
			error: function (xhr,status,error) {
	            alert("Status: " + status);
	            alert("Error: " + error);
	            alert("xhr: " + xhr.readyState);
	        }
		});
	});
});