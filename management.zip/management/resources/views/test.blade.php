@extends('master')

@section('title', 'Pdfdfgdge')



@section('content')
    <p>This is my body content.</p>
@endsection

@section('conte2')
    <p>Tdfgdfntent.</p>
@endsection

