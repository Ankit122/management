@extends('master')

@section('title', 'Pdfdfgdge')



@section('content')
    <p>This is my body content.</p>
@endsection

