<!DOCTYPE html>
<html>
    <head>
        <title>Intact Employee</title>

        <link href='https://fonts.googleapis.com/css?family=Lato:400,100,300,700' rel='stylesheet' type='text/css'>
        <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
        <script src="https://code.jquery.com/jquery-1.10.2.js"></script>
        <script src="http://code.jquery.com/jquery-1.11.0.min.js"></script>
        <style>
            html, body {
                height: 100%;
            }

            body {
                margin: 0;
                padding: 0;
                width: 100%;
                color: #666;
                font-weight: 400;
                font-family: 'Lato';
            }

            .container{
                margin: auto; width: 980px;
            }

            .title {
                font-size: 96px;
                font-weight: 100;
                text-align: center;
                line-height: 300px;
            }
            a:hover{
                color: red;
            }
        </style>
    </head>
    <body>



        <div class="container">
           <!--  <div style="float:left; width: 100%; text-align: right; margin-top: 15px;">
                 <a href="#">Sign Out</a>
            </div> -->
            <div class="content">
            <div class="title">Intact HR</div>
            </div>
            <div class="jumbotron">
            <div class="row">
            <div class="col-md-4 col-md-offset-4">
            <div class="form_bg">
            <?php echo $__env->make('layout.error-notification', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <form class="form-group" method="post" action="<?php echo e(url('signin')); ?>"> 
                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>"> 
                   <!--  SYSTEMNAME Start -->
                    
                    <input type="hidden" value="<?php echo getenv('COMPUTERNAME');?>" name="machine_mac_name" > <!--  SYSTEMNAME Ends -->
                      <!--  SYSTEM Time Start -->
                    <input type="hidden"  id="system_time_signin" name="system_time_signin">
                     <!--  SYSTEM Time ends -->
                        <!--  SYSTE Date Start -->
                    <input type="hidden"  name="system_date" id="system_date">
                     <!--  SYSTEM Date ends -->
                     <!--  Server Date -->
                    <input type="hidden"  name="server_date" value="<?php echo  date("Y-m-d") ;?>">
                     <!--  Server Date ends -->
                     <!-- Server time -->
                    <input type="hidden"  name="server_time_signin" value="<?php  date_default_timezone_set("Asia/Calcutta"); echo  date("h:i:s") ;?>">
                <span>  
                <h4 class="form-signin-heading" style="text-align: center;">Employee Signin Here</h4>
                
                </span>
                  <input type="text" class="form-control" name="emp_id" value="<?php echo e(old('emp_id')); ?>" placeholder="Employee ID" id="emp_id"/>&nbsp;
                  <input type="text" class="form-control" name="emp_screenname" placeholder="Employee Name" id="emp_name" />&nbsp;  
                  <textarea class="form-control" rows="4" name="comments" placeholder="Comments Here.."></textarea> &nbsp;   
                 <button class="btn btn-lg btn-primary btn-block" type="submit">Signin</button>   
                </form>
                </div>
             
            </div>
          </div>
          </div>
        </div>
    </body>
</html>
<script type="text/javascript">
   var today = new Date();
   
   
   // console.log(today);

    var dd = today.getDate();
    var mm = today.getMonth()+1; //January is 0!
    var yyyy = today.getFullYear();

    if(dd<10) {
        dd='0'+dd
    } 

    if(mm<10) {
        mm='0'+mm
    } 

    today = yyyy+'-'+mm+'-'+dd;

    document.getElementById('system_date').value=today;
   
</script>
<script type="text/javascript">
   var today1 = new Date();
   // console.log(today1);

    var HH = today1.getHours();
    var MM = today1.getMinutes();
    var SS = today1.getSeconds();

    today1 = HH+':'+MM+':'+SS;

    document.getElementById('system_time_signin').value=today1;
</script>