<!DOCTYPE html>
<html lang="en">

<head>
    <title>App Name - <?php echo $__env->yieldContent('title'); ?></title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('css/bootstrap.min.css')); ?>">
</head>
<body>
      <nav role="navigation" class="navbar navbar-inverse">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
        <button type="button" data-target="#navbarCollapse" data-toggle="collapse" class="navbar-toggle">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
        </button>
        <a href="<?php echo e(URL('/')); ?>" class="navbar-brand">HR Site</a>
    </div>
    <!-- Collection of nav links, forms, and other content for toggling -->
    <div id="navbarCollapse" class="collapse navbar-collapse">
        <ul class="nav navbar-nav">
            <li class="active"><a href="<?php echo e(URL('emp_list')); ?>">Employee List</a></li>
            <li><a href="<?php echo e(URL('addEmployee')); ?>">Add Employee</a></li>
             <li><a href="<?php echo e(URL('signin_signout_report')); ?>">Sign In | Sign Out Report</a></li>
             <li><a href="<?php echo e(URL('is_terminate')); ?>">Employee Terminations</a></li>
            <!--  <li><a href="<?php echo e(URL('expence')); ?>">Add Expenses</a></li>
            <li><a href="<?php echo e(URL('expence_list')); ?>">Expenses List</a></li> -->
             
        </ul>
        <ul class="nav navbar-nav navbar-right">
            <li><a href="<?php echo e(URL('logout')); ?>">Logout</a></li>
        </ul>
    </div>
</nav>
  
     <!-- /#wrapper -->
       <?php echo $__env->yieldContent('content'); ?>
     <!-- jQuery -->
     <script src="js/jquery.js"></script>
     <script src="js/bootstrap.min.js"></script>
     <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.2/jquery.min.js"></script>
     
        <?php echo $__env->yieldContent('pagescript'); ?>
  
</body>
</html>
