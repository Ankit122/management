<?php $__env->startSection('title', 'Non-Terminated'); ?>
         <?php $__env->startSection('content'); ?>
<h3>Non-Terminated</h3>
 <?php echo $__env->make('layout.error-notification', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <table class="display" id="datatable">
                    <thead>
                      <tr>
                        <th>Sr.No.</th>
                        <th> Name</th>
                        <th>Employee ID</th>
                        <th>Joining Date</th>
                        <th>Termination Date</th>
                        <th>Terminated</th>
                        <th>Status</th>
                      </tr>
                      </thead>
                      <tbody>
                      <?php
                       $employee_details = DB::table('employee_detail')->select('*')->where('is_terminate', '=', 'no')->orderBy('emp_firstname', 'asc')->get();
                      $i=1;
                      foreach($employee_details  as $val){
                      ?>
                      <tr>
                        <td><?php echo e($i); ?></td>
                        <td><?php echo e($val->emp_firstname); ?> <?php echo e($val->emp_middlename); ?> <?php echo e($val->emp_lastname); ?></td>
                        <td><?php echo e($val->emp_id); ?></td>
                        <td><?php echo e(date('d-m-Y', strtotime($val->joining_date))); ?></td>
                        <td><?php echo e($val->termination_date); ?></td>
                        <td><?php echo e($val->is_terminate); ?></td>
                        <td><?php echo e($val->status); ?></td>
                      </tr>
                      <?php
                      $i++;
                      }
                      ?>
                       </tbody>
                    </table>
            
               
        <?php $__env->stopSection(); ?>

         <?php $__env->startSection('pagescript'); ?>
        <link rel="stylesheet" type="text/css" href="//cdn.datatables.net/1.10.12/css/jquery.dataTables.min.css">
        <script type="text/javascript" src="//cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js"></script>

        <script type="text/javascript">
          $(document).ready(function(){
            $('#datatable').DataTable();
          });
        </script>
        <script type="text/javascript">
          $('#datatable').dataTable({
    'columnDefs': [{ 'orderable': false, 'targets': 5 }], // hide sort icon on header of first column
    'aaSorting': [[6, 'asc']] // start to sort data in second column
});
        </script>
       

        <?php $__env->stopSection(); ?>

<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>