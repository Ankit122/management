<!DOCTYPE html>
<html>
    <head>
        <title>Update Employee</title>
        <link rel="stylesheet" type="text/css" href="<?php echo e(url('css/bootstrap.min.css')); ?>">
        
    </head>
    <body>

        <div class="container">
        <div class="jumbotron">
            <div class="row">
                <div class="col-lg-8 col-lg-offset-2">
                    <h3>Update Employee</h3>
                    <?php if(session('err')): ?>
                        <div class="alert alert-danger">
                            <?php echo e(session('err')); ?>

                        </div>
                    <?php endif; ?>
                    <?php if(session('message')): ?>
                        <div class="alert alert-success">
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                              <span aria-hidden="true">&times;</span>
                            </button>
                            <?php echo e(session('message')); ?>

                        </div>
                    <?php endif; ?>
                <form method="post" action="<?php echo e(URL('all_detail')); ?>">
               
                      <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                      <div class="form-group"> 
                 <div class="col-sm-4">
                   <h3>First Name</h3>
                    <input type="text" class="form-control" name="emp_firstname" placeholder="First Name"  autofocus="" maxlength="15" value="fghfg" />
                 </div>
                 <div class="col-sm-4">
                 <h3>Middle Name</h3>
                 <input type="text" class="form-control" name="emp_middlename" placeholder="Middle Name"  autofocus="" maxlength="15" />
                 </div>
                 <div class="col-sm-4">
                   <h3>Last Name</h3>
                    <input type="text" class="form-control" name="emp_lastname" placeholder="Last Name" autofocus="" maxlength="15" />
                 </div>
                 <div class="col-sm-4">
                   <h3>Employee ID</h3>
                    <input type="text" class="form-control" name="emp_id" placeholder="Employee ID"  autofocus="" maxlength="10"/>
                 </div>
                 <div class="col-sm-4">
                   <h3>Designation</h3>
                    <input type="text" class="form-control" name="emp_designation" placeholder="Designation" autofocus="" maxlength="15" />
                 </div>
                 <div class="col-sm-4">
                   <h3>Department</h3>
                     <input type="text" class="form-control" name="emp_department" placeholder="Department"  autofocus="" maxlength="15" />
                 </div>   
                 <div class="col-sm-4">
                   <h3>Joining Date</h3>
                     <input type="text" class="form-control" name="joining_date" placeholder="Joining Date"  autofocus="" />
                 </div> 
                 <div class="col-sm-4">
                   <h3>Termination Date</h3>
                    <input type="text" class="form-control" name="termination_date" placeholder="Termination Date" autofocus=""/>
                 </div> 
                  <div class="col-sm-4">
                   <label class="radio-inline">
                    <h3>Status</h3>
                      <input type="radio" name="status" >Active&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                      <input type="radio" name="status" >De-Active
                    </label>
                     </div>&nbsp;&nbsp;&nbsp;&nbsp;
                      <!-- <div class="col-md-4 col-md-offset-4">
                     <button class="btn btn-lg btn-primary btn-block" type="submit">Submit Details </button>   
                     </div> -->
                       </div>
                      <button type="submit" class="btn btn-default">Update</button>
                       </form>
                </div>
            </div>
            </div>
        </div>

        <script type="text/javascript" src="<?php echo e(url('js/jquery.js')); ?>"></script>
        <script type="text/javascript" src="<?php echo e(url('js/bootstrap.min.js')); ?>"></script>
    </body>
</html>
