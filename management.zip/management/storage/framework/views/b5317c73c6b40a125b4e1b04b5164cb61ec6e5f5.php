<?php $__env->startSection('title', 'Employee List'); ?>
         <?php $__env->startSection('content'); ?>
<h3>Employee List</h3>
 <?php echo $__env->make('layout.error-notification', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <table class="display" id="datatable">
                    <thead>
                      <tr>
                        <th>Sr.No.</th>
                        <th> Name</th>
                        <th>Employee ID</th>
                        <th>Photo</th>
                        <th>Designation</th>
                        <th>Department</th>
                        <th>Joining Date</th>
                        <th>Status</th>
                        <th>Action</th>
                      </tr>
                      </thead>
                      <tbody>
                      <?php
                      $employee_details = DB::table('employee_detail')->select('*')
                      ->where('is_terminate', 'no')->orderBy('emp_firstname', 'asc')->get();
                      $i=1;
                      foreach($employee_details  as $val){
                      ?>
                      <tr>
                        <td><?php echo e($i); ?></td>
                        <td><?php echo e($val->emp_firstname); ?> <?php echo e($val->emp_middlename); ?> <?php echo e($val->emp_lastname); ?></td>
                        <td><?php echo e($val->emp_id); ?></td>
                        <td><img onerror="this.style.display='none'" src="emp/thumb200X300/<?php echo e($val->emp_photo); ?>" width="64"></td>
                        <td><?php echo e($val->emp_designation); ?></td>
                        <td><?php echo e($val->emp_department); ?></td>
                        <td><?php echo e(date('d-m-Y', strtotime($val->joining_date))); ?></td>
                        <td><?php 
                      $ancTxt = '';
                      if($val->status == '1'){
                        $ancTxt = '<span class="text-success">At Work</span>';
                      }
                      
                      if($val->status == '0'){
                        $ancTxt = '<span class="text-warning">De-Active</span>';
                      }
                      echo $ancTxt;
                      ?></td>
                        <td><a href="<?php echo e(url('edit_Empform/'.$val->id)); ?>">Edit</a>|<a onclick="return confirm('Delete this Event?')" href="<?php echo e(url('delete/'.$val->id)); ?>">Delete</a></td>
                      </tr>
                      <?php
                      $i++;
                      }
                      ?>
                       </tbody>
                    </table>
            
               
        <?php $__env->stopSection(); ?>

         <?php $__env->startSection('pagescript'); ?>
        <link rel="stylesheet" type="text/css" href="//cdn.datatables.net/1.10.12/css/jquery.dataTables.min.css">
        <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/buttons/1.2.1/css/buttons.dataTables.min.css">
        <script type="text/javascript" src="//cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js"></script>
         <script type="text/javascript" src="https://cdn.datatables.net/buttons/1.2.1/js/dataTables.buttons.min.js"></script>
          <script type="text/javascript" src="//cdn.datatables.net/buttons/1.2.1/js/buttons.flash.min.js"></script>
           <script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/jszip/2.5.0/jszip.min.js"></script>
            <script type="text/javascript" src="//cdn.rawgit.com/bpampuch/pdfmake/0.1.18/build/pdfmake.min.js"></script>
             <script type="text/javascript" src="//cdn.rawgit.com/bpampuch/pdfmake/0.1.18/build/vfs_fonts.js"></script>
               <script type="text/javascript" src="//cdn.datatables.net/buttons/1.2.1/js/buttons.html5.min.js"></script>
               <script type="text/javascript" src="//cdn.datatables.net/buttons/1.2.1/js/buttons.print.min.js"></script>

        <script type="text/javascript">
         $(document).ready(function() {
    $('#datatable').DataTable( {
        dom: 'Bfrtip',
        buttons: [
            'copy', 'csv', 'excel', 'pdf', 'print'
        ]
    } );
} );
        </script>
        <script type="text/javascript">
          $('#datatable').dataTable({
    'columnDefs': [{ 'orderable': false, 'targets': 5 }], // hide sort icon on header of first column
    'aaSorting': [[6, 'asc']] // start to sort data in second column
});
        </script>
       

        <?php $__env->stopSection(); ?>

<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>