<!DOCTYPE html>
<html>
    <head>
        <title>intact hr - Employee list</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" type="text/css" href="<?php echo e(url('css/bootstrap.min.css')); ?>">
   </head>
    <body>
         <div class="container">
            <div class="row">   
             <div class="col-lg-8 col-lg-offset-2">
                    <h1>Employee List</h1>
                    <?php if(session('message')): ?>
                        <div class="alert alert-success">
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                              <span aria-hidden="true">&times;</span>
                            </button>
                            <?php echo e(session('message')); ?>

                        </div>
                    <?php endif; ?>
                    <table class="table table-condensed table-bordered">
                      <tr>
                        <th>Sr.No.</th>
                        <th>First Name</th>
                        <th>Middle Name</th>
                        <th>Last Name</th>
                        <th>Employee ID</th>
                        <th>Designation</th>
                        <th>Department</th>
                        <th>Joining Date</th>
                        <th>Termination date</th>
                        <th>Status</th>
                        <th>Action</th>
                      </tr>
                      <?php
                      $employee_details = DB::table('employee_detail')->select('*')->paginate(4);
                      $i=1;
                      foreach($employee_details  as $val){
                      ?>
                      <tr>
                        <td><?php echo e($i); ?></td>
                        <td><?php echo e($val->emp_firstname); ?></td>
                        <td><?php echo e($val->emp_middlename); ?></td>
                        <td><?php echo e($val->emp_lastname); ?></td>
                        <td><?php echo e($val->emp_id); ?></td>
                        <td><?php echo e($val->emp_designation); ?></td>
                        <td><?php echo e($val->emp_department); ?></td>
                        <td><?php echo e($val->joining_date); ?></td>
                        <td><?php echo e($val->termination_date); ?></td>
                        <td><?php echo e($val->status); ?></td>
                        <td><a href="<?php echo e(url('edit_form'.$val->emp_id)); ?>">Edit</a>|<a href="<?php echo e(url('delete/'.$val->emp_id)); ?>">Delete</a></td>
                      </tr>
                      <?php
                      $i++;
                      }
                      ?>
                      
                    </table>
                </div>
                <div  class="col-lg-12" style="margin-left:400px">
                  
                  <?php echo $employee_details->render(); ?>

                
                </div>
                </div>
              </div>
               <script src="<?php echo e(url('plugins/jQuery/jQuery-2.1.4.min.js')); ?>"></script>
             <script type="text/javascript" src="<?php echo e(url('js/jquery.js')); ?>"></script>
          <script type="text/javascript" src="<?php echo e(url('js/bootstrap.min.js')); ?>"></script>
           <script src="<?php echo e(url('plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(url('plugins/datatables/dataTables.bootstrap.min.js')); ?>"></script>
           <script>
      $(function () {
        $("#example1").DataTable();
      });
    </script>
    </body>
</html>
