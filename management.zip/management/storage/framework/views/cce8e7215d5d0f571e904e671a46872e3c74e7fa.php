               <div class="col-lg-4 col-lg-offset-4">
                  <a href="<?php echo e(url('viewall')); ?>">View All</a>
                  <a href="<?php echo e(url('form1')); ?>">Form1</a>
                  <a href="<?php echo e(url('form2')); ?>">Form2</a>

                </div>