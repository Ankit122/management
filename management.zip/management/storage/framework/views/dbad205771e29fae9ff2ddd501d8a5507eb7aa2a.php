<?php if( Session::has('errors') ): ?>
<div class="alert alert-danger" role="alert" align="left">
<ul class="errlist">
<?php foreach($errors->all() as $error): ?> 
<li><?php echo e($error); ?></li>
<?php endforeach; ?>
</ul>
</div>
<?php endif; ?>

<?php if( Session::has('message') ): ?>
<div class="alert alert-success" role="alert">
<?php echo e(Session::get('message')); ?>

</div>
<?php endif; ?>

<?php if( Session::has('singleerror') ): ?>
<div class="alert alert-danger" role="alert">s
<?php echo e(Session::get('singleerror')); ?>

</div>
<?php endif; ?>

<?php if( Session::has('error') ): ?>
<div class="alert alert-danger" role="alert">
<?php echo e(Session::get('error')); ?>

</div>
<?php endif; ?>