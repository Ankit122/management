<!DOCTYPE html>
<html>
    <head>
        <title>Laravel</title>

        <link href='https://fonts.googleapis.com/css?family=Lato:400,100,300,700' rel='stylesheet' type='text/css'>
        <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
        <style>
            html, body {
                height: 100%;
            }

            body {
                margin: 0;
                padding: 0;
                width: 100%;
                color: #666;
                font-weight: 400;
                font-family: 'Lato';
            }

            .container{
                margin: auto; width: 980px;
            }

            .title {
                font-size: 96px;
                font-weight: 100;
                text-align: center;
                line-height: 300px;
            }
            a:hover{
                color: red;
            }
        </style>
    </head>
    <body>



        <div class="container">
           <div style="float:left; width: 100%; text-align: right; margin-top: 15px;">
              <!-- <?php
              if(Auth::check()){
              ?>
                 <a href="<?php echo e(url('logout')); ?>">Sign Out</a>
              <?php }?> -->
            </div>
            <div class="content">
            <div class="title">Intact HR</div>
            </div>
            <div class="jumbotron">
            <div class="row">
            <div class="col-sm-12">
            <div class="form_bg">
                <?php echo $__env->make('layout.error-notification', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <form class="form-group" method="post" action="<?php echo e(url('editEmployee')); ?>" enctype="multipart/form-data">  
                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>"> 
                <input type="hidden" name="id" value="<?php echo e($emp_detail[0]->id); ?>">       
                <h2 class="form-signin-heading" style="text-align: center;">Edit Employee Detail </h2>
                  <?php if($emp_detail[0]->emp_photo){?>
                  <div class="col-lg-12">
                    <div class="thumbnail">
                      <img src="<?php echo e(url('emp/thumb200X300/'.$emp_detail[0]->emp_photo)); ?>">
                    </div>
                  </div> 
                  <?php }?>
                 <div class="col-sm-4">
                 <h3>First Name</h3>
                <input type="text" class="form-control" name="emp_firstname" placeholder="First Name" maxlength="15" id="emp_firstname" value ="<?php echo e($emp_detail[0]->emp_firstname); ?>"/>
                 </div>
                 <div class="col-sm-4">
                 <h3>Middle Name</h3>
                <input type="text" class="form-control" name="emp_middlename" placeholder="Middle Name" maxlength="15" id="emp_middlename" value="<?php echo e($emp_detail[0]->emp_middlename); ?>"/>
                 </div>
                 <div class="col-sm-4">
                 <h3>Last Name</h3>
                <input type="text" class="form-control" name="emp_lastname" placeholder="Last Name" maxlength="15" id="emp_middlename" value="<?php echo e($emp_detail[0]->emp_lastname); ?>"/>
                 </div>
                 <div class="col-sm-4">
                 <h3>Employee ID</h3>
                <input type="text" class="form-control" name="emp_id" placeholder="Employee ID"maxlength="10" id="emp_id" value="<?php echo e($emp_detail[0]->emp_id); ?>"/>
                 </div>
                 <div class="col-sm-4">
                 <h3>Designation</h3>
                <input type="text" class="form-control" name="emp_designation" placeholder="Designation" maxlength="15" id="emp_designation" value="<?php echo e($emp_detail[0]->emp_designation); ?>"/>
                 </div>
                 <div class="col-sm-4">
                 <h3>Department</h3>
                <input type="text" class="form-control" name="emp_department" placeholder="Department" maxlength="15" id="emp_department" value="<?php echo e($emp_detail[0]->emp_department); ?>"/>
                 </div>   
                 <div class="col-sm-4">
                 <h3>Joining Date</h3>
                <input type="date" class="form-control" name="joining_date" placeholder="Joining Date" id="joining_date"value="<?php echo e($emp_detail[0]->joining_date); ?>"/>
                 </div> 
                 <div class="col-sm-4">
                 <h3>Termination Date</h3>
                <input type="date" class="form-control" name="termination_date" placeholder="Termination Date" id="termination_date" value="<?php echo e($emp_detail[0]->termination_date); ?>"/>
                 </div>
                  <div class="col-sm-4" style="float: left;">
                  <label class="radio-inline">
                  <h3>Status</h3>
                      <input type="radio" name="status" value="1"<?php echo ($emp_detail[0]->status==1)?'checked':''?>>Active&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                      <input type="radio" name="status" value="0"<?php echo ($emp_detail[0]->status==0)?'checked':''?>>De-Active
                    </label>
                     </div>&nbsp;&nbsp;
                     <div class="col-sm-4" >
                    <label style="margin-top: 2px" >Select a image to upload</label>
                   <input type="file" name="emp_photo">
                 </div>
                      <div class="col-md-4 col-md-offset-4">
                     <button class="btn btn-lg btn-primary" type="submit">Update</button>   
                     </div>

                </form>
                </div>
             
            </div>

          </div>
          </div>
        </div>
    </body>
</html>
 
